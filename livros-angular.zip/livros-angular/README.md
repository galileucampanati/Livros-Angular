# livros-angular

Trabalho prático da disciplina **DGT2809 – Aprofundamento em Desenvolvimento Front-End**.

Catálogo de livros em Angular (Angular 17, NgModule, Angular Routing, CSS, Bootstrap):

- `/lista` – tabela de livros, com exclusão;
- `/dados` – formulário de inclusão de livro.

## Como executar

```bash
npm install
ng serve
```

Acesse http://localhost:4200/.
